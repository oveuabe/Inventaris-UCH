export default function Home() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold">UCH Scanner</h1>
      <p className="mt-2">Gunakan menu "Scanner" untuk mulai memindai inventaris.</p>
    </main>
  );
}
